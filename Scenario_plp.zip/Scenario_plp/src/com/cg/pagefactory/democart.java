package com.cg.pagefactory;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class democart {
	WebDriver driver;
	@FindBy(css=".list-inline .dropdown-toggle")
	public WebElement myAccount;
	
	@FindBy(linkText="Login")
	public WebElement loginoption;
	
	@FindBy(css=".btn:nth-child(3)")
	public WebElement loginbtn;
	
	@FindBy(id="input-email")
	public WebElement emailtxt;
	
	@FindBy(id="input-password")
	public WebElement pwd;
	
	@FindBy(linkText="Modify your address book entries")
	public WebElement addressbook;
	
	@FindBy(linkText="New Address")
	public WebElement addAddress;
	
	@FindBy(id="input-firstname")
	public WebElement fname;
	
	@FindBy(id="input-lastname")
	public WebElement lname;
	
	@FindBy(id="input-company")
	public WebElement company ;
	
	@FindBy(id="input-address-1")
	public WebElement address1;
	
	@FindBy(id="input-address-2")
	public WebElement address2;
	
	@FindBy(id="input-city")
	public WebElement city;
	
	@FindBy(id="input-postcode")
	public WebElement postcode;
	
	@FindBy(id="input-country")
	public WebElement countrylist;
	
	@FindBy(id="input-zone")
	public WebElement statelist;
		
	@FindBy(css=".btn-primary")
	public WebElement continuebtn;
	
	@FindBy(linkText="Your Store")
	public WebElement homenav;
	
	@FindBy(linkText="iPhone")
	public WebElement product;
	
	@FindBy(id="input-quantity")
	public WebElement quantity;
	
	@FindBy(id="button-cart")
	public WebElement addtocart;
	
	@FindBy(xpath="//li[4]/a/i")
	public WebElement opencartt;
	
	
	@FindBy(css="a > .fa-shopping-cart")
	public WebElement opencart;
	
	@FindBy(xpath="//button[2]/i")
	public WebElement removeitems;
	
	@FindBy(css=".fa-times-circle")
	public WebElement removeitem;
	
	@FindBy(linkText="Continue")
	public WebElement continuebt;
	
	@FindBy(css=".dropdown-menu > li:nth-child(5) > a")
	public WebElement logout;
	/*
	@FindBy()
	public WebElement ;
	
	@FindBy()
	public WebElement ;
	
	@FindBy()
	public WebElement ;*/
public democart(WebDriver driver1) {
		
		this.driver=driver1;
		PageFactory.initElements(driver1, this);
	}

}

package com.cg.demoRunner;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Hashtable;
import java.util.List;

import org.apache.pdfbox.exceptions.COSVisitorException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.cg.ExcelReader.ReadFromExcel;
import com.cg.pagefactory.democart;
import com.cg.pdfutility.PdfUtility;



public class DemoRunner {
	
	democart dc;
	WebDriver driver;
	PdfUtility pdfUtility=new PdfUtility();
	List<String> resultList=new ArrayList<String>();
	
	@BeforeClass
	public void DemoCart() {
		System.setProperty("webdriver.chrome.driver",System.getProperty("user.dir")+"/Driver/chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("https://demo.opencart.com/");
		driver.manage().window().maximize();
		dc = new democart(driver);
	}
	
	@Test(priority = 1,dataProvider = "LoginDetails")
	public void Login(Hashtable<String, String> tb) throws InterruptedException {
		dc.myAccount.click();
		dc.loginoption.click();
		dc.emailtxt.clear();
		dc.emailtxt.sendKeys(tb.get("Email"));
		Thread.sleep(1000);
		dc.pwd.clear();
		dc.pwd.sendKeys(tb.get("Password"));
		Thread.sleep(1000);
		dc.loginbtn.click();
		if(driver.getTitle().equals("My Account")) {
			resultList.add("1, Login to the site,User should be able to login, User logged in, Passed");
		}
		else
		{
			resultList.add("1, Login to the site,User should be able to login, User logged in, Failed");
		}
	}	
	
	@Test(priority = 2,dataProvider = "Addressbook")
	public void AddingAddress(Hashtable<String, String> tb) throws InterruptedException, NoSuchElementException{
		dc.addressbook.click();
		Thread.sleep(1000);
		dc.addAddress.click();
		dc.fname.sendKeys(tb.get("FirstName"));
		Thread.sleep(1000);
		dc.lname.sendKeys(tb.get("LastName"));
		Thread.sleep(1000);
		dc.company.sendKeys(tb.get("Company"));
		Thread.sleep(1000);
		dc.address1.sendKeys(tb.get("Address1"));
		Thread.sleep(1000);
		dc.address2.sendKeys(tb.get("Address2"));
		Thread.sleep(1000);
		dc.city.sendKeys(tb.get("City"));
		Thread.sleep(1000);
		dc.postcode.sendKeys(tb.get("PostCode"));
		Thread.sleep(1000);
		Select s = new Select(dc.countrylist);
		s.selectByValue("99");
		Thread.sleep(2000);
		Select ss = new Select(dc.statelist);
		ss.selectByIndex(30);
		dc.continuebtn.click();
		resultList.add("2, Adding Address to address book,User should be able to add address, User added address, Pass");
		}
		
	@Test(priority = 3)
	public void AddingItemintoCart() throws InterruptedException {
		dc.homenav.click();
		dc.product.click();
		dc.quantity.clear();
		dc.quantity.sendKeys("5");

		dc.addtocart.click();
		resultList.add("3, Adding product to cart,User should be able to add product to cart, User added product to cart, Pass");
	}
	
	@Test(priority = 4)
	public void RemovingfromCart() throws InterruptedException {
		Thread.sleep(1000);
		dc.opencartt.click();
		Thread.sleep(2000);
		dc.removeitems.click();
		Thread.sleep(2000);
		dc.continuebtn.click();
		resultList.add("4, Removing product to cart,User should be able to remove product to cart, User removed product to cart, Pass");
	
	}	
		
	@Test(priority = 5)
	public void Logout() throws InterruptedException {
		dc.myAccount.click();	
		dc.logout.click();
		Thread.sleep(2000);
		dc.continuebtn.click();
		resultList.add("5, Logout to the site,User should be able to logout, User logged out, Pass");
	}
	

	 
	
	@DataProvider
	public Object[][] LoginDetails() throws IOException, InvalidFormatException {

		String filename = "Login.xlsx";
		String filepath= System.getProperty("user.dir")+"/src/com/cg/testdata";
		String sheetname = "Sheet1";
		return ReadFromExcel.ReadExcelData(filepath, filename, sheetname);
	}
	
	@DataProvider
	public Object[][] Addressbook() throws IOException, InvalidFormatException {

		String filename = "Addressbook.xlsx";
		String filepath= System.getProperty("user.dir")+"/src/com/cg/testdata";
		String sheetname = "Sheet1";
		return ReadFromExcel.ReadExcelData(filepath, filename, sheetname);
	}
	
	
	 @AfterClass
	  public void TearDown() throws COSVisitorException, IOException {
	  //close the driver
	 driver.close();
	 //define a time stamp string to add to the test result 
	 String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(Calendar.getInstance().getTime());
	 //add time stamp to the resultList
	 resultList.add("Test Ends: " + timeStamp);
	 //write the test result pdf file with file name TestResult
	  pdfUtility.WriteTestResultToPdfFile("TestResult.pdf", resultList); 
	  //quit the driver
	 driver.quit();
	  }
	

}